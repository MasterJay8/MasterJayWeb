<script setup>
// Swap /logo.svg and /banner.svg in /public for your own images.
</script>

<template>
  <header class="header">
    <div class="header__inner">
      <RouterLink to="/" class="header__logo" aria-label="Home">
        <img src="/logo.svg" alt="Logo" width="52" height="52" />
      </RouterLink>

      <div class="header__banner">
        <img src="/banner.svg" alt="" />
      </div>

      <nav class="header__nav" aria-label="Main">
        <RouterLink to="/">Links</RouterLink>
        <RouterLink to="/about">About</RouterLink>
      </nav>
    </div>
  </header>
</template>

<style lang="scss" scoped>
@use '@/styles/variables' as *;

.header {
  background: $ink;
  padding: 0.9rem 1.5rem;

  &__inner {
    max-width: $content-width + 240px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: auto minmax(0, 1fr) auto;
    align-items: center;
    gap: 1.5rem;

    @include md-down {
      grid-template-columns: auto 1fr;
      grid-template-areas:
        'logo nav'
        'banner banner';
      gap: 0.9rem 1rem;
    }
  }

  &__logo {
    display: block;
    border-radius: 16px;
    transition: transform 0.2s ease;
    &:hover { transform: rotate(-6deg); }
    @include md-down { grid-area: logo; }
  }

  &__banner {
    justify-self: center;
    width: 100%;
    max-width: 520px;
    height: 76px;
    border-radius: $radius-sm;
    overflow: hidden;
    @include md-down { grid-area: banner; max-width: none; height: 64px; }

    img { width: 100%; height: 100%; object-fit: cover; }
  }

  &__nav {
    display: flex;
    gap: 0.4rem;
    @include md-down { grid-area: nav; justify-self: end; }

    a {
      color: $lilac;
      text-decoration: none;
      font-weight: 500;
      padding: 0.45rem 0.9rem;
      border-radius: 999px;
      transition: background 0.15s ease, color 0.15s ease;

      &:hover { background: rgba($lilac, 0.15); }
      &.router-link-exact-active { background: $sun; color: $ink; }
    }
  }
}
</style>
