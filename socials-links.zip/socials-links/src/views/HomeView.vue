<script setup>
import SocialLink from '@/components/SocialLink.vue'
import { socials } from '@/data/socials'
</script>

<template>
  <div class="page">
    <h1 class="title">Find me online</h1>
    <p class="subtitle">Pick a platform, I post different things on each.</p>

    <ul class="list">
      <li v-for="s in socials" :key="s.name">
        <SocialLink v-bind="s" />
      </li>
    </ul>
  </div>
</template>

<style lang="scss" scoped>
@use '@/styles/variables' as *;

.title {
  font-size: clamp(2.2rem, 6vw, 3.6rem);
  font-weight: 800;
  letter-spacing: -0.02em;
}

.subtitle {
  margin: 0.8rem 0 2.2rem;
  color: $ink-soft;
  font-size: 1.1rem;
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1rem;

  @include md-down { grid-template-columns: 1fr; }
}
</style>
