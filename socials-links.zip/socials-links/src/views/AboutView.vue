<template>
  <div class="page">
    <h1 class="title">About</h1>
    <p>Write something about yourself here.</p>
  </div>
</template>

<style lang="scss" scoped>
.title {
  font-size: clamp(2.2rem, 6vw, 3.6rem);
  font-weight: 800;
  margin-bottom: 1rem;
}
</style>
