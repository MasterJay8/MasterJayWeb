# Socials links (Vue 3 + Vue Router + SCSS)

    npm install
    npm run dev

- Add/edit links: `src/data/socials.js`
- Logo / banner: replace `public/logo.svg` and `public/banner.svg`
- Icons: drop images into `public/icons/` and reference them in `socials.js`
- Colors & sizes: `src/styles/_variables.scss`
- Link card component: `src/components/SocialLink.vue` (props: `name`, `link`, `img`, optional `color`)
